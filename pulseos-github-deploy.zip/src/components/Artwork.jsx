export function HeroArtwork() {
  return (
    <svg viewBox="0 0 640 420" className="hero-art" aria-hidden="true">
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#38bdf8" />
          <stop offset="50%" stopColor="#8b5cf6" />
          <stop offset="100%" stopColor="#f43f5e" />
        </linearGradient>
        <linearGradient id="glass" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="rgba(255,255,255,0.28)" />
          <stop offset="100%" stopColor="rgba(255,255,255,0.08)" />
        </linearGradient>
      </defs>
      <rect x="40" y="30" width="560" height="360" rx="32" fill="#0f172a" />
      <circle cx="98" cy="94" r="34" fill="#f8fafc" opacity="0.95" />
      <path d="M90 302c34-56 73-84 120-84 54 0 86 39 122 39 26 0 49-10 78-34-34 87-102 135-194 135-67 0-112-18-126-56z" fill="url(#sky)" opacity="0.95" />
      <rect x="114" y="102" width="160" height="110" rx="24" fill="url(#glass)" stroke="rgba(255,255,255,0.18)" />
      <rect x="306" y="88" width="212" height="136" rx="28" fill="url(#glass)" stroke="rgba(255,255,255,0.18)" />
      <rect x="140" y="128" width="78" height="14" rx="7" fill="#e2e8f0" opacity="0.85" />
      <rect x="140" y="154" width="106" height="10" rx="5" fill="#cbd5e1" opacity="0.55" />
      <rect x="140" y="174" width="88" height="10" rx="5" fill="#cbd5e1" opacity="0.35" />
      <circle cx="470" cy="146" r="24" fill="#22c55e" opacity="0.85" />
      <path d="M458 145l10 10 18-22" stroke="#f8fafc" strokeWidth="8" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <rect x="340" y="188" width="138" height="10" rx="5" fill="#e2e8f0" opacity="0.55" />
      <rect x="340" y="206" width="100" height="10" rx="5" fill="#cbd5e1" opacity="0.35" />
      <rect x="338" y="278" width="166" height="52" rx="18" fill="url(#glass)" stroke="rgba(255,255,255,0.18)" />
      <rect x="364" y="298" width="86" height="10" rx="5" fill="#f8fafc" opacity="0.8" />
    </svg>
  )
}

export function MiniScene() {
  return (
    <svg viewBox="0 0 520 320" className="mini-scene" aria-hidden="true">
      <defs>
        <linearGradient id="g2" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#22d3ee" />
          <stop offset="100%" stopColor="#a855f7" />
        </linearGradient>
      </defs>
      <rect width="520" height="320" rx="28" fill="#020617" />
      <path d="M46 236c30-50 76-72 118-72 46 0 74 18 118 18 35 0 68-10 124-46-34 92-102 138-204 138-77 0-128-14-156-38z" fill="url(#g2)" />
      <circle cx="96" cy="84" r="24" fill="#f8fafc" opacity="0.95" />
      <rect x="256" y="62" width="180" height="122" rx="24" fill="rgba(255,255,255,0.08)" stroke="rgba(255,255,255,0.16)" />
      <rect x="286" y="94" width="94" height="12" rx="6" fill="#e2e8f0" opacity="0.75" />
      <rect x="286" y="118" width="118" height="10" rx="5" fill="#cbd5e1" opacity="0.45" />
      <rect x="286" y="138" width="90" height="10" rx="5" fill="#cbd5e1" opacity="0.3" />
    </svg>
  )
}
