export function Logo() {
  return (
    <div className="logo-wrap">
      <div className="logo-mark">P</div>
      <div>
        <div className="logo-title">PulseOS</div>
        <div className="logo-sub">Your life, organized</div>
      </div>
    </div>
  )
}

export function SectionCard({ title, subtitle, action, children }) {
  return (
    <section className="card section-card">
      <div className="section-header">
        <div>
          <h3>{title}</h3>
          {subtitle ? <p>{subtitle}</p> : null}
        </div>
        {action}
      </div>
      {children}
    </section>
  )
}

export function EmptyState({ title, text }) {
  return (
    <div className="empty-state">
      <strong>{title}</strong>
      <p>{text}</p>
    </div>
  )
}
