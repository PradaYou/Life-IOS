import { useEffect, useMemo, useState } from 'react'
import { Navigate, Route, Routes, Link, useNavigate } from 'react-router-dom'
import { HeroArtwork, MiniScene } from './components/Artwork'
import { EmptyState, Logo, SectionCard } from './components/UI'
import { createUserProfile, getCurrentUser, loadState, saveState } from './lib/storage'

function App() {
  const [state, setState] = useState(loadState())

  useEffect(() => {
    saveState(state)
  }, [state])

  const currentUser = getCurrentUser(state)

  const setCurrentUserData = (updater) => {
    if (!currentUser) return
    setState((prev) => {
      const user = prev.users[prev.currentUserId]
      const updatedUser = updater(user)
      return {
        ...prev,
        users: {
          ...prev.users,
          [updatedUser.id]: updatedUser,
        },
      }
    })
  }

  const authActions = {
    signup: ({ name, email, password }) => {
      const profile = createUserProfile({ name, email: email.toLowerCase(), password })
      setState((prev) => ({
        ...prev,
        currentUserId: profile.id,
        users: {
          ...prev.users,
          [profile.id]: profile,
        },
      }))
    },
    login: ({ email, password }) => {
      const user = Object.values(state.users).find(
        (entry) => entry.email === email.toLowerCase() && entry.password === password,
      )
      if (!user) throw new Error('No account matched that email and password.')
      setState((prev) => ({ ...prev, currentUserId: user.id }))
    },
    logout: () => setState((prev) => ({ ...prev, currentUserId: null })),
  }

  return (
    <Routes>
      <Route path="/" element={currentUser ? <Navigate to="/app" replace /> : <LandingPage />} />
      <Route path="/auth" element={currentUser ? <Navigate to="/app" replace /> : <AuthPage actions={authActions} />} />
      <Route
        path="/app"
        element={
          currentUser ? (
            <Dashboard user={currentUser} setCurrentUserData={setCurrentUserData} logout={authActions.logout} state={state} setState={setState} />
          ) : (
            <Navigate to="/auth" replace />
          )
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

function LandingPage() {
  return (
    <div className="page landing-page">
      <header className="topbar shell">
        <Logo />
        <nav className="top-nav">
          <a href="#features">Features</a>
          <a href="#how">How it works</a>
          <Link className="btn btn-soft" to="/auth">Sign in</Link>
          <Link className="btn btn-primary" to="/auth">Get started</Link>
        </nav>
      </header>

      <main>
        <section className="hero shell">
          <div className="hero-copy">
            <div className="eyebrow">Life operating system</div>
            <h1>Run your day from one calm, powerful dashboard.</h1>
            <p>
              PulseOS brings together tasks, habits, notes, planning, focus sessions, and smart daily guidance so you always know what matters next.
            </p>
            <div className="hero-actions">
              <Link className="btn btn-primary large" to="/auth">Create your space</Link>
              <a className="btn btn-soft large" href="#features">See what it does</a>
            </div>
            <div className="stat-row">
              <div className="stat-pill"><strong>Tasks</strong><span>Priority-based action list</span></div>
              <div className="stat-pill"><strong>Habits</strong><span>Track consistency daily</span></div>
              <div className="stat-pill"><strong>Planner</strong><span>Know what is next</span></div>
            </div>
          </div>
          <div className="hero-visual">
            <HeroArtwork />
          </div>
        </section>

        <section id="features" className="feature-grid shell">
          {[
            ['Daily command center', 'See tasks due today, upcoming events, habits, and guided priorities on one screen.'],
            ['Built-in focus support', 'Start a focus timer, protect deep work, and stay in motion without switching apps.'],
            ['Notes and planning', 'Capture thoughts, meeting notes, personal reminders, and next actions in seconds.'],
            ['Simple sign-in flow', 'Create an account instantly and keep your workspace saved in the browser.'],
          ].map(([title, text]) => (
            <article className="card feature-card" key={title}>
              <h3>{title}</h3>
              <p>{text}</p>
            </article>
          ))}
        </section>

        <section id="how" className="split shell">
          <div>
            <div className="eyebrow">Why it feels useful</div>
            <h2>It tells you what deserves attention now.</h2>
            <p>
              Instead of becoming another place to dump lists, PulseOS highlights overdue items, today’s priorities, unfinished habits, and your next scheduled event.
            </p>
            <ul className="clean-list">
              <li>Fast task capture with due dates and priorities</li>
              <li>Habit tracking with streaks</li>
              <li>Notes, goals, and schedule blocks</li>
              <li>Smart daily recommendation cards</li>
            </ul>
          </div>
          <MiniScene />
        </section>
      </main>
    </div>
  )
}

function AuthPage({ actions }) {
  const [mode, setMode] = useState('signup')
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const submit = (e) => {
    e.preventDefault()
    setError('')
    try {
      if (mode === 'signup') {
        if (!form.name.trim()) throw new Error('Add your name to create the account.')
        actions.signup(form)
      } else {
        actions.login(form)
      }
      navigate('/app')
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <div className="auth-page page shell auth-shell">
      <div className="auth-panel auth-copy">
        <Logo />
        <div className="eyebrow">Welcome to PulseOS</div>
        <h1>One app for the things you need to remember, finish, and improve.</h1>
        <p>Set up your account, land in your dashboard, and start organizing your life immediately.</p>
        <MiniScene />
      </div>
      <div className="auth-panel card auth-form-wrap">
        <div className="switcher">
          <button className={mode === 'signup' ? 'active' : ''} onClick={() => setMode('signup')}>Create account</button>
          <button className={mode === 'login' ? 'active' : ''} onClick={() => setMode('login')}>Sign in</button>
        </div>
        <form className="auth-form" onSubmit={submit}>
          {mode === 'signup' && (
            <label>
              Name
              <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your name" />
            </label>
          )}
          <label>
            Email
            <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" />
          </label>
          <label>
            Password
            <input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="••••••••" />
          </label>
          {error ? <div className="error-box">{error}</div> : null}
          <button className="btn btn-primary full" type="submit">{mode === 'signup' ? 'Create workspace' : 'Enter dashboard'}</button>
        </form>
        <p className="tiny-note">This demo stores account data in your browser so you can deploy instantly with no backend setup.</p>
      </div>
    </div>
  )
}

function Dashboard({ user, setCurrentUserData, logout, state, setState }) {
  const data = user.data
  const [taskForm, setTaskForm] = useState({ title: '', due: '', category: 'General', priority: 'Medium' })
  const [noteForm, setNoteForm] = useState({ title: '', body: '' })
  const [eventForm, setEventForm] = useState({ title: '', date: '', time: '', location: '' })
  const [timerSeconds, setTimerSeconds] = useState(25 * 60)
  const [running, setRunning] = useState(false)

  useEffect(() => {
    if (!running) return
    const id = setInterval(() => {
      setTimerSeconds((sec) => {
        if (sec <= 1) {
          setRunning(false)
          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('PulseOS focus session complete', { body: 'Nice work. Take a short reset or start another block.' })
          }
          return 25 * 60
        }
        return sec - 1
      })
    }, 1000)
    return () => clearInterval(id)
  }, [running])

  const today = new Date().toISOString().slice(0, 10)
  const completedTasks = data.tasks.filter((task) => task.completed).length
  const pendingTasks = data.tasks.filter((task) => !task.completed).length
  const overdue = data.tasks.filter((task) => !task.completed && task.due && task.due < today)
  const todayTasks = data.tasks.filter((task) => !task.completed && task.due === today)
  const nextEvent = [...data.events].sort((a, b) => `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`))[0]

  const recommendations = useMemo(() => {
    const items = []
    if (overdue.length) items.push({ title: 'Clear overdue items', text: `You have ${overdue.length} overdue ${overdue.length === 1 ? 'task' : 'tasks'} to close out first.` })
    if (todayTasks.length) items.push({ title: 'Finish today’s priorities', text: `${todayTasks.length} ${todayTasks.length === 1 ? 'item is' : 'items are'} due today.` })
    const undoneHabits = data.habits.filter((habit) => !habit.completedToday)
    if (undoneHabits.length) items.push({ title: 'Protect your streaks', text: `${undoneHabits.length} habit${undoneHabits.length === 1 ? '' : 's'} still need attention today.` })
    if (nextEvent) items.push({ title: 'Prepare for your next block', text: `${nextEvent.title} is coming up on ${formatDate(nextEvent.date)} at ${nextEvent.time}.` })
    if (!items.length) items.push({ title: 'You are in a good place', text: 'No urgent gaps right now. Add your next task or start a focus session.' })
    return items.slice(0, 4)
  }, [overdue.length, todayTasks.length, data.habits, nextEvent])

  const updateData = (nextData) => setCurrentUserData((existing) => ({ ...existing, data: nextData }))

  const addTask = (e) => {
    e.preventDefault()
    if (!taskForm.title.trim()) return
    updateData({
      ...data,
      tasks: [{ id: crypto.randomUUID(), completed: false, ...taskForm }, ...data.tasks],
    })
    setTaskForm({ title: '', due: '', category: 'General', priority: 'Medium' })
  }

  const toggleTask = (id) => {
    updateData({
      ...data,
      tasks: data.tasks.map((task) => (task.id === id ? { ...task, completed: !task.completed } : task)),
    })
  }

  const deleteTask = (id) => updateData({ ...data, tasks: data.tasks.filter((task) => task.id !== id) })

  const addNote = (e) => {
    e.preventDefault()
    if (!noteForm.title.trim() && !noteForm.body.trim()) return
    updateData({
      ...data,
      notes: [{ id: crypto.randomUUID(), ...noteForm, updatedAt: new Date().toISOString() }, ...data.notes],
    })
    setNoteForm({ title: '', body: '' })
  }

  const addEvent = (e) => {
    e.preventDefault()
    if (!eventForm.title.trim()) return
    updateData({
      ...data,
      events: [...data.events, { id: crypto.randomUUID(), ...eventForm }],
    })
    setEventForm({ title: '', date: '', time: '', location: '' })
  }

  const toggleHabit = (id) => {
    updateData({
      ...data,
      habits: data.habits.map((habit) => {
        if (habit.id !== id) return habit
        const completedToday = !habit.completedToday
        return {
          ...habit,
          completedToday,
          streak: completedToday ? habit.streak + 1 : Math.max(0, habit.streak - 1),
        }
      }),
    })
  }

  const enableNotifications = async () => {
    if (!('Notification' in window)) return
    const permission = await Notification.requestPermission()
    setState((prev) => ({ ...prev, notificationsEnabled: permission === 'granted' }))
  }

  return (
    <div className="dashboard page shell">
      <header className="dashboard-topbar">
        <Logo />
        <div className="dashboard-actions">
          <button className="btn btn-soft" onClick={enableNotifications}>Enable reminders</button>
          <button className="btn btn-primary" onClick={logout}>Log out</button>
        </div>
      </header>

      <section className="welcome-strip card">
        <div>
          <div className="eyebrow">Good to see you, {user.name.split(' ')[0]}</div>
          <h1>Here is your command center for today.</h1>
          <p>Track what matters, act on the right tasks, and keep your day moving without losing context.</p>
        </div>
        <div className="quick-stats">
          <div><strong>{pendingTasks}</strong><span>Open tasks</span></div>
          <div><strong>{completedTasks}</strong><span>Completed</span></div>
          <div><strong>{data.habits.filter((h) => h.completedToday).length}</strong><span>Habits done</span></div>
        </div>
      </section>

      <section className="recommend-grid">
        {recommendations.map((item) => (
          <article className="card recommend-card" key={item.title}>
            <h3>{item.title}</h3>
            <p>{item.text}</p>
          </article>
        ))}
      </section>

      <section className="dashboard-grid">
        <div className="main-column">
          <SectionCard title="Tasks" subtitle="Capture and act on what needs to happen next" action={<span className="badge">{pendingTasks} active</span>}>
            <form className="inline-form grid-four" onSubmit={addTask}>
              <input placeholder="Add a task" value={taskForm.title} onChange={(e) => setTaskForm({ ...taskForm, title: e.target.value })} />
              <input type="date" value={taskForm.due} onChange={(e) => setTaskForm({ ...taskForm, due: e.target.value })} />
              <select value={taskForm.category} onChange={(e) => setTaskForm({ ...taskForm, category: e.target.value })}>
                <option>General</option>
                <option>Work</option>
                <option>Health</option>
                <option>Personal</option>
                <option>Planning</option>
              </select>
              <select value={taskForm.priority} onChange={(e) => setTaskForm({ ...taskForm, priority: e.target.value })}>
                <option>Low</option>
                <option>Medium</option>
                <option>High</option>
              </select>
              <button className="btn btn-primary" type="submit">Add task</button>
            </form>
            <div className="list-wrap">
              {data.tasks.length ? data.tasks.map((task) => (
                <div className="list-row task-row" key={task.id}>
                  <label className="task-main">
                    <input type="checkbox" checked={task.completed} onChange={() => toggleTask(task.id)} />
                    <div>
                      <strong className={task.completed ? 'done' : ''}>{task.title}</strong>
                      <div className="meta">{task.category} · {task.priority}{task.due ? ` · Due ${formatDate(task.due)}` : ''}</div>
                    </div>
                  </label>
                  <button className="ghost-btn" onClick={() => deleteTask(task.id)}>Delete</button>
                </div>
              )) : <EmptyState title="No tasks yet" text="Add your first task and it will appear here." />}
            </div>
          </SectionCard>

          <SectionCard title="Notes" subtitle="Quick thoughts, reminders, and plans">
            <form className="stack-form" onSubmit={addNote}>
              <input placeholder="Note title" value={noteForm.title} onChange={(e) => setNoteForm({ ...noteForm, title: e.target.value })} />
              <textarea rows="4" placeholder="Write anything you want to remember" value={noteForm.body} onChange={(e) => setNoteForm({ ...noteForm, body: e.target.value })} />
              <button className="btn btn-primary" type="submit">Save note</button>
            </form>
            <div className="notes-grid">
              {data.notes.map((note) => (
                <article className="note-card" key={note.id}>
                  <strong>{note.title || 'Untitled note'}</strong>
                  <p>{note.body}</p>
                  <span>Updated {new Date(note.updatedAt).toLocaleDateString()}</span>
                </article>
              ))}
            </div>
          </SectionCard>
        </div>

        <aside className="side-column">
          <SectionCard title="Planner" subtitle="Upcoming schedule blocks and reminders">
            <form className="stack-form" onSubmit={addEvent}>
              <input placeholder="Event title" value={eventForm.title} onChange={(e) => setEventForm({ ...eventForm, title: e.target.value })} />
              <div className="dual-inputs">
                <input type="date" value={eventForm.date} onChange={(e) => setEventForm({ ...eventForm, date: e.target.value })} />
                <input type="time" value={eventForm.time} onChange={(e) => setEventForm({ ...eventForm, time: e.target.value })} />
              </div>
              <input placeholder="Location or context" value={eventForm.location} onChange={(e) => setEventForm({ ...eventForm, location: e.target.value })} />
              <button className="btn btn-primary" type="submit">Add event</button>
            </form>
            <div className="schedule-list">
              {[...data.events].sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`)).map((event) => (
                <div className="schedule-item" key={event.id}>
                  <strong>{event.title}</strong>
                  <span>{formatDate(event.date)} {event.time ? `· ${event.time}` : ''}</span>
                  {event.location ? <small>{event.location}</small> : null}
                </div>
              ))}
            </div>
          </SectionCard>

          <SectionCard title="Habits" subtitle="Small wins that stack up">
            <div className="habit-list">
              {data.habits.map((habit) => (
                <button className={`habit-chip ${habit.completedToday ? 'done-chip' : ''}`} key={habit.id} onClick={() => toggleHabit(habit.id)}>
                  <span>{habit.title}</span>
                  <strong>{habit.streak} day streak</strong>
                </button>
              ))}
            </div>
          </SectionCard>

          <SectionCard title="Goals" subtitle="Keep your larger direction visible">
            <div className="goal-list">
              {data.goals.map((goal) => (
                <div className="goal-item" key={goal.id}>
                  <div className="goal-row"><strong>{goal.title}</strong><span>{goal.progress}%</span></div>
                  <div className="progress-bar"><div style={{ width: `${goal.progress}%` }} /></div>
                </div>
              ))}
            </div>
          </SectionCard>

          <SectionCard title="Focus timer" subtitle="Protect one block of real attention">
            <div className="timer-wrap">
              <div className="timer-face">{formatTimer(timerSeconds)}</div>
              <div className="timer-actions">
                <button className="btn btn-primary" onClick={() => setRunning((v) => !v)}>{running ? 'Pause' : 'Start'}</button>
                <button className="btn btn-soft" onClick={() => { setRunning(false); setTimerSeconds(25 * 60) }}>Reset</button>
              </div>
            </div>
          </SectionCard>
        </aside>
      </section>
    </div>
  )
}

function formatDate(value) {
  if (!value) return 'No date'
  const [y, m, d] = value.split('-').map(Number)
  return new Date(y, m - 1, d).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
}

function formatTimer(total) {
  const mins = Math.floor(total / 60).toString().padStart(2, '0')
  const secs = (total % 60).toString().padStart(2, '0')
  return `${mins}:${secs}`
}

export default App
