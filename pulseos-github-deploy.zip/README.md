# PulseOS

PulseOS is a deployable life dashboard built with React and Vite. It includes:

- Landing page with custom artwork
- Create account and sign in flow
- Task management with due dates, categories, and priorities
- Habit tracking with daily completion and streaks
- Notes section
- Planner / event blocks
- Goals progress cards
- Focus timer
- Browser notification support for focus session completion

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Deploy to Vercel

1. Upload the project to GitHub.
2. Import the repo into Vercel.
3. Framework preset: Vite
4. Build command: `npm run build`
5. Output directory: `dist`

This project also includes a `vercel.json` rewrite for SPA routing.

## Important note

This version stores data in `localStorage`, so it works immediately without backend setup. For production multi-device auth and syncing, connect Supabase or Firebase next.
